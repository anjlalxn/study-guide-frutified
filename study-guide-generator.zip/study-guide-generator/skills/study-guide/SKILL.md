---
name: study-guide
description: Creates structured, student-friendly study guides and downloadable PDF reviewers from topics, uploaded notes, slides, readings, class reports, exam material, presentations, defenses, or codebases. Use whenever the user asks for a reviewer, study guide, study notes, lesson summary, exam preparation, presentation preparation, or a multi-part guide, even if they do not explicitly request a PDF. For programming topics, include source-grounded code walkthroughs, method tables, and system flows when code is available.
---

# Study Guide Generator

Create a study guide that helps a student understand the material, remember it, and explain it aloud or answer questions about it. Prefer clear explanations over compressed notes. Explain why concepts matter, connect related ideas, and use examples grounded in the supplied material.

## Operating principles

1. **Use the user's source first.** Read the uploaded files, pasted text, or linked repository material that is available. If the user provides only a topic, use reliable established knowledge and clearly distinguish general explanation from course-specific material.
2. **Do not fabricate source details.** Never invent quotations, page numbers, code, definitions attributed to a lecturer, results, or facts supposedly found in an upload. Flag missing or ambiguous details. If the material is current or likely to have changed, verify it using reliable sources when browsing is available.
3. **Preserve course terminology.** Keep the names and phrasing used in the user's slides or lecturer's material, then explain them in simpler language. Do not silently replace the instructor's approach with a different framework.
4. **Teach for understanding.** Assume the reader is a student who may be new to the topic. Define jargon at first use, use short sentences, explain cause and effect, and include the reasoning behind procedures.
5. **Be complete but selective.** Prioritize examinable concepts and meaningful details. Remove repetition and filler without dropping important qualifications.
6. **Deliver the artifact.** When file-generation tools are available, create and attach the finished PDF. If PDF generation is unavailable, provide the complete guide in a clean Markdown document rather than claiming a PDF was created.

## Source handling

### Slides and presentations

Skip slides that contain no lesson content, such as:
- Cover slides containing only the title, names, or course details
- "Thank you", "Questions?", or closing slides
- Prepared-by, presented-by, reporter, or group-member lists
- Agenda or outline-only slides, unless the outline is needed to explain the lesson structure
- References-only slides (use them only to identify sources when needed)
- Slides containing only a logo, date, or contact information

Use the substantive lesson content. Do not mention skipped filler slides in the guide.

### Multiple sources

Reconcile overlapping material, retain useful differences in emphasis, and identify genuine contradictions instead of silently choosing one. If a source is unreadable or only partially available, state the limitation and continue with the material that can be verified.

### Repositories and code

Inspect the actual files relevant to the user's question. Do not describe a function, route, variable, or database field unless it appears in the accessible source. If the repository cannot be accessed, ask for the relevant files or explain that the code-specific section cannot yet be verified.

## Workflow

1. Identify the subject, intended use (exam, class report, presentation, defense, or general learning), source material, and requested scope.
2. If scope is obvious, proceed without asking questions. For a very large topic, propose a logical split such as "Guide 1 of 3" and start with the first useful portion. Ask one concise clarification only when a missing detail would materially change the guide.
3. Choose a color theme using the rules below.
4. Build a content outline before writing. Organize concepts in a teachable order, from foundational ideas to applications.
5. Write the guide using the content structure below.
6. Generate the PDF when file tools are available. Inspect representative pages for clipping, broken tables, missing glyphs, and layout problems; revise if necessary.
7. Attach the actual generated file. Briefly state the scope covered, the selected theme, and (for a multi-part topic) what the next guide will cover.

## Content structure

Use this structure where it fits the material; do not force irrelevant sections into a short or narrow topic.

1. **Intro block** — a short, friendly orientation followed by a numbered list of what the reader should be able to understand or do.
2. **Part banners** — divide substantial material into numbered parts with short descriptive titles.
3. **Concept first, details second** — begin each major concept with a plain-language explanation or analogy (for example, "Think of it this way"), then provide a diagram-like flow, card, list, or table where useful, followed by the technical detail.
4. **Worked example** — include a numbered walkthrough, solved problem, or realistic scenario.
5. **Numbered sections** — use labels such as `1.1`, `1.2`, and `2.1`. For each major concept, include a definition, why it matters, and an example. Add comparison tables when they clarify distinctions.
6. **Review helpers** — include relevant items near the end of each part or at the end of the guide:
   - Key terms with one-line meanings
   - Likely professor or exam questions with concise model answers
   - Quick recap bullets
   - For reports, presentations, thesis work, or defenses: a first-person sample explanation the student can say aloud
7. **Self-check** — add a small set of questions or prompts that test understanding, not just memorization. Include answers separately when useful.

Keep paragraphs short. Bold key terms. Explain abbreviations on first use. Avoid padding the guide with generic motivational text.

## Programming and IT topics

Add these elements when the lesson is about programming, software engineering, databases, networking, or a technical system and the source supports them:

- Real code snippets in fenced code blocks with the language identified.
- A plain-language walkthrough explaining important lines and how the code executes.
- Method, function, route, command, variable, or database-field tables (`Name | Purpose | Where/how it is used`).
- A flow showing how components connect, such as request → route → controller → model/database → response, or input → processing → output.
- Architecture cards for concepts such as Model / View / Controller or Model / Template / View.
- Likely "Explain this code" questions with short model answers.

**Code accuracy rules:**
- Code must come from the user's provided source or an accessible repository. Never invent code and present it as the user's implementation.
- Preserve the language, framework, naming, and style used in the course or codebase.
- Explain what the code actually does, including limitations or potential bugs when relevant. Do not claim a feature exists merely because it would be conventional.
- If only a partial file is available, label the explanation as based on that excerpt.
- Skip code blocks and method tables for non-programming subjects.

## Color themes

Each theme has three colors: **primary** (title banner, bullets, inline-code text, pills, rules), **dark** (part banners, section headings, table headers, bold terms, list numerals, code accent), and **tint** (inline-code background, cards, alternating table rows). Use white text on primary and dark backgrounds, so keep both sufficiently dark for contrast.

| Theme | Primary | Dark | Tint |
|---|---|---|---|
| Raspberry (default) | `#D93868` | `#1F4D2B` | `#FDEEF2` |
| Strawberry | `#E0334C` | `#2F5D2E` | `#FDECEE` |
| Blueberry | `#4A5BC4` | `#1E2A5A` | `#EEF0FC` |
| Orange | `#E8761A` | `#6B3A12` | `#FFF1E4` |
| Mango | `#D98A0B` | `#7A4A0A` | `#FFF5DD` |
| Lemon | `#B89A00` | `#4F5A12` | `#FBF7D9` |
| Lime | `#5E9E1F` | `#23441C` | `#EEF7DF` |
| Kiwi | `#6E9B2F` | `#3B2F1E` | `#F1F7E4` |
| Grape | `#8244B0` | `#2E1A4A` | `#F4ECFA` |
| Plum | `#9B2F5F` | `#3A1730` | `#F9EAF1` |
| Watermelon | `#E5445F` | `#1F5B3A` | `#FDECEF` |
| Peach | `#E8795A` | `#7A3B2B` | `#FEEEE8` |

Shared neutral tokens: code background `#F4F7F4`, ink `#222222`, muted text `#555555`, divider `#E3E3E3`.

### Theme selection

- If the user names a theme, use it.
- If the user says "default" or gives no color preference, use Raspberry.
- If the user says "random", "surprise me", or "any", choose one of the themes other than Raspberry and tell them which one was selected. Do not claim a random process was used unless one was actually used.
- If the user says "you decide", choose a theme that suits the subject (for example, Blueberry for IT/networking, Kiwi or Lime for biology/environment, Grape for literature/arts, Orange for chemistry) and state the choice.
- If the user supplies custom colors, map them to primary, dark, and tint. Check contrast before using white text.

Use the selected fruit as a small emblem in the title banner (a simple icon or fruit illustration). Keep it decorative and secondary to the title.

## Visual design system

Create an A4 portrait PDF with approximately 14 mm margins, white page background, and a polished two-column reading layout. Aim for body text around 9.5–10 pt with comfortable leading. Keep the title banner and footer full-width; use a thin divider between columns.

- **Title banner** — on the first page, use a rounded primary-color banner with a thicker dark bottom edge. Include a white circular fruit emblem, a small uppercase monospace eyebrow (`SUBJECT · STUDY GUIDE · GUIDE 1 OF 3`), and a bold white title around 22 pt (`Topic — Reviewer`).
- **Part banner** — dark background, 4 pt primary left accent, small uppercase part label in tint, and a bold white part title.
- **Section heading** — dark bold heading around 14 pt with a 2 pt primary rule beneath it. Use smaller dark subheadings for subsections.
- **Emphasis** — bold key terms in dark. Use primary-color bullets and dark numbered-list markers.
- **Concept cards** — tint background, thin primary border, rounded corners, and a bold primary label. Use smaller white inner cards with a dark left accent for definitions, categories, or components.
- **Tables** — dark header with white bold text, alternating white and tint rows, thin separators, and sensible column widths. Repeat header rows across pages where supported.
- **Inline code** — monospace text in primary color on a tint background.
- **Code blocks** — code-background fill, subtle border, dark left accent, monospace font around 8–8.5 pt, and a small primary language label. Wrap long lines safely; never let code run beyond the page edge.
- **Footer** — thin primary rule, subject and "Study guide" at left, `Page X of Y` at right.
- Keep headings with their following content. Avoid splitting tables, cards, and code blocks across pages when possible.

## PDF generation and fallback

When a Python or equivalent file-generation tool is available, create a real PDF file and attach it to the response. Prefer a document-generation library that supports page layout, tables, headers, and footers. In a Python environment, use ReportLab Platypus (`SimpleDocTemplate` / `BaseDocTemplate`, `Paragraph`, `Table`, `KeepTogether`, and page templates) to construct the PDF. Use a two-column page template where practical; if the renderer cannot reliably support a full-width first-page banner with columns, use a full-width title area followed by two-column content, or use a clean single-column layout rather than producing broken output.

Use Finlandica Text for body/headings and JetBrains Mono for code and labels when those font files are available. Embed the fonts in the PDF. If they are not available, use readable embedded Unicode-capable alternatives and disclose the substitution briefly; do not claim the preferred fonts were embedded when they were not. Do not depend on Google Fonts being reachable at render time.

If PDF creation fails, do not fabricate a download link. Provide the complete guide as Markdown and explain that the PDF export could not be completed. If the guide is too large for one document, split it into clearly named parts and create each file separately when supported.

## Quality checklist

Before delivery, verify:
- The guide covers the substantive lesson material and omits filler slides.
- Every source-specific fact, term, example, and code snippet is supported by the supplied material.
- Important concepts have plain-language explanations and useful examples.
- Review questions have accurate, concise model answers.
- Programming guides explain actual code and match the source's style.
- Theme colors are consistent and text contrast is readable.
- Fonts are embedded or any substitution is disclosed.
- Tables, cards, and code fit within page boundaries; no text is clipped.
- Page numbering is correct and the subject appears in the footer.
- The attached file is the actual generated PDF, not a placeholder.

At delivery, summarize what the guide covers, name the selected theme, and identify the next part if the topic was split.
