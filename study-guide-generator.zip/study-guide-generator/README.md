# Study Guide Generator

A skills-only ChatGPT plugin that turns topics, class notes, slide decks, readings, and accessible codebases into structured, student-friendly study guides. It is designed to produce polished PDF reviewers when file-generation capabilities are available.

## Features

- Plain-language explanations, analogies, and worked examples
- Organized sections, concept cards, comparison tables, and review summaries
- Likely exam or professor questions with model answers
- First-person sample explanations for reports, presentations, and defenses
- Source-grounded code walkthroughs and method tables for programming topics
- Twelve fruit-inspired color themes and an A4 two-column visual design direction
- PDF generation guidance with a Markdown fallback when PDF export is unavailable

## Package contents

```text
study-guide-generator/
├── plugin.json
├── README.md
└── skills/
    └── study-guide/
        └── SKILL.md
```

## Use

Install the plugin package in a compatible ChatGPT/plugin environment, then ask for a study guide. You can provide a topic directly or attach notes, slides, readings, or source files. Specify a color theme if desired; Raspberry is the default.

Example prompt:

> Turn my uploaded lesson into a complete study guide. Use the Blueberry theme, include worked examples and likely exam questions, and export it as a PDF.

## Important notes

- This is a **skills-only plugin**. It contains workflow instructions; it does not bundle a separate MCP server, external API, or PDF-rendering service.
- Actual PDF creation depends on the host environment's available file-generation tools and fonts. If PDF export is unavailable, the skill directs the assistant to provide the guide in Markdown instead.
- The plugin does not include user-uploaded course materials or generated study guides.

## Design attribution

The study-guide workflow and visual design direction were adapted from the `study-guide-frutified` project by CrimsonCrows. The source skill's two-column page structure, fruit-inspired color themes, banner hierarchy, typography choices, and recurring card/table treatments informed this package.

Source: https://github.com/crimsoncrows/study-guide-frutified

## License

No license is included in this package. Add a license only after deciding what permissions you want to grant for reuse, modification, and redistribution, and confirming that the upstream material's license permits your intended distribution.
